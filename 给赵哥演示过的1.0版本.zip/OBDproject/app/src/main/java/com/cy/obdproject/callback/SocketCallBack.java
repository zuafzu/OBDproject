package com.cy.obdproject.callback;

public interface SocketCallBack {

    void getData(String data);

}
